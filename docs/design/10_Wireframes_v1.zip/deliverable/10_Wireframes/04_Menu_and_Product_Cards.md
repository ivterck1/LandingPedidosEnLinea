# 04 — Menu and Product Cards

## Anatomía de producto

1. Imagen o espacio reservado.
2. Etiqueta opcional: especialidad, nuevo o agotado.
3. Nombre.
4. Descripción de una o dos líneas.
5. Precio en MXN.
6. Control **Agregar**.

## Estados

| Estado | Presentación |
| --- | --- |
| Disponible | Botón Agregar activo |
| Agregado | Confirmación breve; carrito actualizado |
| Varias unidades | Cantidad se gestiona principalmente desde el carrito |
| Agotado | Etiqueta visible y control deshabilitado |
| Sin imagen | Placeholder editorial legítimo, no archivo de imagen falso |

## Categorías propuestas para validar

- Especialidades.
- Ceviches.
- Tostadas.
- Cocteles.
- Complementos.
- Bebidas.

Estas categorías son hipótesis de arquitectura, no catálogo confirmado.

## Fuente de verdad

Cada producto debe tener un identificador, nombre, descripción, categoría, precio, disponibilidad e imagen. Ninguno de esos datos se duplica manualmente entre menú, carrito y WhatsApp.

