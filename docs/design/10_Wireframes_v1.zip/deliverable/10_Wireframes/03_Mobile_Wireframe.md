# 03 — Mobile Wireframe

## Viewport de referencia

390 × 844 px como base de diseño; debe funcionar desde 320 px.

## Orden y comportamiento

1. Header de una línea: logo, menú y carrito.
2. Hero apilado con un CTA dominante.
3. Confianza en carrusel accesible o lista breve.
4. Especialidades en desplazamiento horizontal con alternativa accesible.
5. Categorías sticky debajo del header.
6. Productos en una columna.
7. Barra inferior de carrito cuando hay productos.
8. Carrito como panel/pantalla de altura completa.
9. Formulario progresivo.
10. Revisión final y salida a WhatsApp.

## Decisión clave

La barra inferior muestra **cantidad, total y “Ver pedido”**. No contiene el formulario ni compite con la navegación del teléfono.

## Etapas del pedido móvil

| Etapa | Contenido |
| --- | --- |
| 1. Pedido | Productos, cantidades, subtotal y eliminar |
| 2. Entrega | Entrega/recolección y campos condicionales |
| 3. Confirmar | Resumen completo y botón de WhatsApp |

## Reglas táctiles

- Objetivos táctiles mínimos de 44 × 44 px.
- Botones de cantidad claramente separados.
- Ningún control depende solo del color.
- La barra inferior respeta el área segura del dispositivo.
- Al abrir el carrito, el foco se mueve al título del panel.
- Cerrar el panel devuelve el foco al disparador.

Plano visual: [`wireframes/mobile-full.svg`](wireframes/mobile-full.svg).

